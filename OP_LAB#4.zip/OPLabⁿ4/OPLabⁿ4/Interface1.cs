﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OPLab_4
{
    interface Interface1
    {
    }
}
